<?php
  session_start();

  include '../common.php';
  $data = new Common();
  $datas = $data->getAll("SELECT * FROM employee");
?>
<?php include 'header.php'?>

<?php include 'sidebar.php' ?>

<!-- top navigation -->
<?php include 'top_nav.php' ?>
<!-- /top navigation -->

<!-- page content -->
<div class="right_col" role="main">
    <div class="exportSearch">
        <!-- <a href="">Export CSV</a> -->
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Search for ..">
            <div class="input-group-append">
            <button class="btn btn-secondary" type="button">
                <i class="fa fa-search"></i>
            </button>
            </div>
        </div>
    </div>

  <table class="table">
    <thead>
      <tr>
        <th>StaffID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Company</th>
        <th>Department</th>
        <th>Phone</th>
        <th>Address</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      foreach($datas as $data):
        $comdta = new Common();
        $comname = $comdta->getAllRow("SELECT company FROM company WHERE comId = ? ", [$data['companyId']]);
       ?>
      <tr>
        <td><?= $data['staffID']; ?></td>
        <td><?= $data['firstName'].' '.$data['lastName']; ?></td>
        <td><?= $data['email']; ?></td>
        <td>
          <?= $comname['company']; ?>
        </td>
        <td><?= $data['department'];?></td>
        <td><?= $data['phone']; ?></td>
        <td><?= $data['address']?></td>
      </tr>
      <?php endforeach;?>
    </tbody>
  </table>
</div>
<!-- /page content -->


<?php include 'footer.php'?>