<?php

    class Common {
        
        public $con;

        function __construct()
        {
            define("ROOT", 'root');
            define("ROOT_PASS", "");
            define("DSN", 'mysql:host=localhost:3306;dbname=company_panel');
            $this->con = new PDO(DSN, ROOT, ROOT_PASS);
        }

        // function data($a, $b, $c){
        //     include 'config.php';
        //     $d = 2;
        //     $z = $a + $b + $c + $d + $this->e + $f;
        //     return $z;
        // }

        //select all data
        function getAll($query) {
            // echo $query;
            // die();
            $data = $this->con->prepare($query);
            $data->execute();
            return $data;
        }

        //select all data where id for edits
        function getAllRow($query, $param = []) {
            $data = $this->con->prepare($query);
            $data->execute($param);
            $datas = $data->fetch(PDO::FETCH_ASSOC);
            return $datas;
        }

        //insert, update, add and delete data to db
        function getAllData($query, $param = []) {
            $sql = $this->con->prepare($query);
            $sql->execute($param);
            return $sql;
        }

        

    }

?>