<?php
    include 'header.php';
?>
<div class="login">
    <?php
        // $pass = md5('12345');
        // echo $pass;
        // exit();
    ?>
    <div>
        <a class="hiddenanchor" id="signup"></a>
        <a class="hiddenanchor" id="signin"></a>

        <div class="login_wrapper">
            <div class="animate form login_form">
            <section class="login_content">
                <?php if(isset($_GET['incorrect'])) : ?>
                    <h4 class = "btn btn-danger">Wrong Email or Password</h4>
                <?php endif; ?>
                <form method="post" action="confirm.php">
                    <h1>Admin Login</h1> 
                    <div>
                        <input type="email" class="form-control" name="email" placeholder="Email" required="" />
                    </div>
                    <div>
                        <input type="password" name="password" class="form-control" placeholder="Password" required="" />
                    </div>
                    <div>
                        <button type="submit" class="btn btn-default submit" name="adminSubmit">Log in</button>  
                    </div>

                    <div class="clearfix"></div>

                    <div class="separator">
                        <p class="change_link">Employee Login？
                            <a href="#signup" class="to_register text-color"> Employee Login</a>
                        </p>

                        <div class="clearfix"></div>
                        <br />

                        <div>
                            <h1><i class="fa fa-building"></i> Company Panel</h1>
                            p>©2021 All Rights Reserved. Company Panel is a template. Privacy and Terms</p>
                        </div>
                    </div>
                </form>
            </section>
            </div>

            <div id="register" class="animate form registration_form">
            <section class="login_content">
                <?php if(isset($_GET['incorrects'])) : ?>
                    <h4 class = "btn btn-danger">Wrong Email or Password</h4>
                <?php endif; ?>
                <form method="post" action="emConfirm.php">
                <h1>Employee Login</h1>
                <div>
                    <input type="email" name="emails" class="form-control" placeholder="Email" required="" />
                </div>
                <div>
                    <input type="password" name="passwords" class="form-control" placeholder="Password" required="" />
                </div>
                <div>
                    <button type="submit" class="btn btn-default submit">Log in</a>
                </div>

                <div class="clearfix"></div>

                <div class="separator">
                    <p class="change_link">Admin Login ?
                    <a href="#signin" class="to_register text-color"> Admin Login </a>
                    </p>

                    <div class="clearfix"></div>
                    <br />

                    <div>
                    <h1><i class="fa fa-group"></i> Emloyee Panel</h1>
                    <p>©2021 All Rights Reserved. Employee Panel is a template. Privacy and Terms</p>
                    </div>
                </div>
                </form>
            </section>
            </div>
        </div>
        </div>
</div>
<?php include 'footer.php' ?>